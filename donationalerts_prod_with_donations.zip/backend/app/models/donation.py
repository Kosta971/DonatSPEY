from sqlalchemy import Column, Integer, String, Float
from ..services.db import Base

class Donation(Base):
    __tablename__ = "donations"
    id = Column(Integer, primary_key=True, index=True)
    amount = Column(Float)
    message = Column(String)
    streamer_id = Column(Integer)