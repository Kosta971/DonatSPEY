from pydantic import BaseModel

class DonationCreate(BaseModel):
    amount: float
    message: str
    streamer_id: int

class DonationResponse(BaseModel):
    id: int
    amount: float
    message: str
    streamer_id: int

    class Config:
        orm_mode = True