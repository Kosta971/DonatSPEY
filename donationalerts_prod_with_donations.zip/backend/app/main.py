from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import users, donations
from app.services.db import Base, engine

app = FastAPI(title="DonationAlerts Clone API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

Base.metadata.create_all(bind=engine)

app.include_router(users.router)
app.include_router(donations.router)

@app.get("/")
def read_root():
    return {"message": "Добро пожаловать в API DonationAlerts Clone"}