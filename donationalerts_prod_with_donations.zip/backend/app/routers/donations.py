from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..models import donation as models
from ..schemas.donation import DonationCreate, DonationResponse
from ..services.db import get_db

router = APIRouter(prefix="/donations", tags=["Donations"])

@router.post("/", response_model=DonationResponse)
def create_donation(donation: DonationCreate, db: Session = Depends(get_db)):
    new_donation = models.Donation(amount=donation.amount, message=donation.message, streamer_id=donation.streamer_id)
    db.add(new_donation)
    db.commit()
    db.refresh(new_donation)
    return new_donation