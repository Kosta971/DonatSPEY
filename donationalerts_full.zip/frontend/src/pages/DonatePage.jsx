import { useState } from 'react';
import axios from 'axios';

export default function DonatePage({ streamerId = 1 }) {
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');

  const donate = async () => {
    try {
      await axios.post('http://localhost:8000/donations/', {
        streamer_id: streamerId,
        amount: parseFloat(amount),
        message,
      });
      alert('Донат отправлен!');
    } catch {
      alert('Ошибка при отправке доната');
    }
  };

  return (
    <div>
      <h2>Поддержать стримера</h2>
      <input value={amount} onChange={e => setAmount(e.target.value)} placeholder="Сумма" />
      <input value={message} onChange={e => setMessage(e.target.value)} placeholder="Сообщение" />
      <button onClick={donate}>Отправить</button>
    </div>
  );
}