import { useState } from 'react';
import axios from 'axios';

export default function RegisterPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const register = async () => {
    try {
      await axios.post('http://localhost:8000/users/register', { email, password });
      alert('Регистрация успешна');
    } catch (err) {
      alert('Ошибка регистрации');
    }
  };

  return (
    <div>
      <h2>Регистрация</h2>
      <input value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" />
      <input value={password} onChange={e => setPassword(e.target.value)} type="password" placeholder="Пароль" />
      <button onClick={register}>Зарегистрироваться</button>
    </div>
  );
}