import { useEffect, useState } from 'react';

export default function OBSWidget() {
  const [donation, setDonation] = useState(null);

  useEffect(() => {
    const socket = new WebSocket('ws://localhost:8000/ws/donations');
    socket.onmessage = (event) => {
      setDonation(JSON.parse(event.data));
    };
    return () => socket.close();
  }, []);

  return donation ? (
    <div style={{ color: 'lime', fontSize: 24 }}>
      💸 {donation.amount} ₽ — {donation.message}
    </div>
  ) : null;
}