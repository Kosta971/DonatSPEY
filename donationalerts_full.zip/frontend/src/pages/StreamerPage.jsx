import { useEffect, useState } from 'react';
import axios from 'axios';

export default function StreamerPage({ streamerId = 1 }) {
  const [streamer, setStreamer] = useState(null);
  const [donations, setDonations] = useState([]);

  useEffect(() => {
    axios.get(`http://localhost:8000/streamer/${streamerId}`)
      .then(res => setStreamer(res.data));
    axios.get(`http://localhost:8000/streamer/${streamerId}/donations`)
      .then(res => setDonations(res.data));
  }, []);

  return (
    <div>
      <h2>Стример: {streamer?.email}</h2>
      <ul>
        {donations.map(d => (
          <li key={d.id}>{d.amount} ₽ — {d.message}</li>
        ))}
      </ul>
    </div>
  );
}